// import moment from 'moment'

// // let formattedDate = moment(createdAt).format('DD-MM-YYYY HH:mm:ss');
export const MyColumns = [
  
  {
    Header: "Operator",
    accessor: "operatorName",
  },
  {
    Header: "Plate",
    accessor: "plateNumber",
  },
  {
    Header: "Operator Type",
    accessor: "operatorType",
  },
  {
    Header: "Remark",
    accessor: "remark",
  },
  {
    Header: "Inspector",
    accessor: "checked_by",
  },
  {
    Header: "Mechanic",
    accessor: "mechanic",
  },
  {
    Header: "Status",
    accessor: "status", 
  },
  {
    Header: "Date",
    accessor: "createdAt",
  },
] 