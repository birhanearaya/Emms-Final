import '../index.css'
import React, { useState } from 'react';
import axios from 'axios'
export const Signup = () => {
  // signup
  const  [userName, setUserName] = useState('');
  const  [role, setRole] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [passwordConfirm, setPasswordConfirm] = useState('');



  const handleSignup = async () => {
    try {
      // const response = await axios.post('http://localhost:5002/api/users/login', { email, password });
      
      const response = await axios.post('http://localhost:5002/api/users/signup', { userName,
      email,
      role,
      password,
      passwordConfirm, });
      console.log(response.data); // Handle the response from the server
 localStorage.setItem('token', response.data.token); 
      window.location.pathname = "/Registration"

      // if successful -> 
      // history.push('/dashboard');
// localStorage.setItem('key', 'value'); 
// const storedData = localStorage.getItem('key'); 
// localStorage.removeItem('key'); 


    } catch (error) {
      console.log(error.response.data.error.statusCode, error.response.data.message); 
      // Handle any errors that occur during the request
    }
  };

  return (
    <div>
      <h1>Signup Page</h1>
      {/* // signup */}
      <form>
        <input
          type="text"
          placeholder="User Name"
          value={userName}
          onChange={(e) => setUserName(e.target.value)}
        />
        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <input
          type="text"
          placeholder="role"
          value={role}
          onChange={(e) => setRole(e.target.value)}
        />
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        <input
          type="password"
          placeholder="confirm Password"
          value={passwordConfirm}
          onChange={(e) => setPasswordConfirm(e.target.value)}
        />
        <button type="button" onClick={handleSignup}>
          Login
        </button>
      </form>
      
    </div>
  );
};
